package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.outlined.Calculate
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Lightbulb
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.TrendingUp
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.preferences.AppLanguage
import com.example.data.preferences.ThemeMode
import com.example.ui.screens.AboutScreen
import com.example.ui.screens.CalculatorScreen
import com.example.ui.screens.HealthTipsScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.TrendsScreen
import com.example.ui.theme.FitLifeTheme
import com.example.viewmodel.BmiViewModel

enum class AppScreen(
    val labelEn: String,
    val labelBn: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
) {
    CALCULATOR(
        labelEn = "Calculator",
        labelBn = "ক্যালকুলেটর",
        selectedIcon = Icons.Filled.Calculate,
        unselectedIcon = Icons.Outlined.Calculate,
        testTag = "nav_calculator"
    ),
    HISTORY(
        labelEn = "History",
        labelBn = "ইতিহাস",
        selectedIcon = Icons.Filled.History,
        unselectedIcon = Icons.Outlined.History,
        testTag = "nav_history"
    ),
    TRENDS(
        labelEn = "Trends",
        labelBn = "প্রবণতা",
        selectedIcon = Icons.Filled.TrendingUp,
        unselectedIcon = Icons.Outlined.TrendingUp,
        testTag = "nav_trends"
    ),
    TIPS(
        labelEn = "Health Tips",
        labelBn = "টিপস",
        selectedIcon = Icons.Filled.Lightbulb,
        unselectedIcon = Icons.Outlined.Lightbulb,
        testTag = "nav_tips"
    ),
    SETTINGS(
        labelEn = "Settings",
        labelBn = "সেটিংস",
        selectedIcon = Icons.Filled.Settings,
        unselectedIcon = Icons.Outlined.Settings,
        testTag = "nav_settings"
    ),
    ABOUT(
        labelEn = "About",
        labelBn = "সম্পর্কিত",
        selectedIcon = Icons.Filled.Settings,
        unselectedIcon = Icons.Outlined.Settings,
        testTag = "nav_about"
    )
}

class MainActivity : ComponentActivity() {

    private val viewModel: BmiViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val userPreferences by viewModel.userPreferences.collectAsStateWithLifecycle()
            val isDarkTheme = when (userPreferences.themeMode) {
                ThemeMode.SYSTEM -> isSystemInDarkTheme()
                ThemeMode.LIGHT -> false
                ThemeMode.DARK -> true
            }

            val isBengali = userPreferences.language == AppLanguage.BENGALI

            FitLifeTheme(darkTheme = isDarkTheme) {
                FitLifeApp(
                    viewModel = viewModel,
                    isBengali = isBengali
                )
            }
        }
    }
}

@Composable
fun FitLifeApp(
    viewModel: BmiViewModel,
    isBengali: Boolean
) {
    var currentScreen by rememberSaveable { mutableStateOf(AppScreen.CALCULATOR) }
    val calculatorState by viewModel.calculatorState.collectAsStateWithLifecycle()
    val records by viewModel.records.collectAsStateWithLifecycle()
    val sortDescending by viewModel.sortDescending.collectAsStateWithLifecycle()
    val userPreferences by viewModel.userPreferences.collectAsStateWithLifecycle()

    // Handle system back gesture
    if (currentScreen != AppScreen.CALCULATOR) {
        BackHandler {
            if (currentScreen == AppScreen.ABOUT) {
                currentScreen = AppScreen.SETTINGS
            } else {
                currentScreen = AppScreen.CALCULATOR
            }
        }
    }

    val bottomNavItems = listOf(
        AppScreen.CALCULATOR,
        AppScreen.HISTORY,
        AppScreen.TRENDS,
        AppScreen.TIPS,
        AppScreen.SETTINGS
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets.safeDrawing,
        bottomBar = {
            if (currentScreen != AppScreen.ABOUT) {
                NavigationBar(
                    modifier = Modifier.navigationBarsPadding(),
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 4.dp
                ) {
                    bottomNavItems.forEach { screen ->
                        val isSelected = currentScreen == screen
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { currentScreen = screen },
                            icon = {
                                Icon(
                                    imageVector = if (isSelected) screen.selectedIcon else screen.unselectedIcon,
                                    contentDescription = screen.labelEn
                                )
                            },
                            label = {
                                Text(
                                    text = if (isBengali) screen.labelBn else screen.labelEn,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                selectedTextColor = MaterialTheme.colorScheme.primary,
                                indicatorColor = MaterialTheme.colorScheme.primaryContainer
                            ),
                            modifier = Modifier.testTag(screen.testTag)
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                AppScreen.CALCULATOR -> {
                    CalculatorScreen(
                        state = calculatorState,
                        isBengali = isBengali,
                        onAgeChange = viewModel::updateAge,
                        onGenderChange = viewModel::updateGender,
                        onWeightChange = viewModel::updateWeight,
                        onHeightCmChange = viewModel::updateHeightCm,
                        onHeightFeetChange = viewModel::updateHeightFeet,
                        onHeightInchesChange = viewModel::updateHeightInches,
                        onWeightUnitChange = viewModel::setWeightUnit,
                        onHeightUnitChange = viewModel::setHeightUnit,
                        onCalculate = viewModel::calculateBmi,
                        onReset = viewModel::resetCalculator,
                        onSaveResult = viewModel::saveCurrentResult,
                        onGeneratePdf = viewModel::generatePdf
                    )
                }
                AppScreen.HISTORY -> {
                    HistoryScreen(
                        records = records,
                        sortDescending = sortDescending,
                        isBengali = isBengali,
                        onToggleSort = viewModel::toggleSortOrder,
                        onDeleteRecord = viewModel::deleteRecord,
                        onClearAll = viewModel::clearAllHistory,
                        onNavigateToCalculator = { currentScreen = AppScreen.CALCULATOR }
                    )
                }
                AppScreen.TRENDS -> {
                    TrendsScreen(
                        records = records,
                        isBengali = isBengali
                    )
                }
                AppScreen.TIPS -> {
                    HealthTipsScreen(
                        isBengali = isBengali
                    )
                }
                AppScreen.SETTINGS -> {
                    SettingsScreen(
                        userPreferences = userPreferences,
                        isBengali = isBengali,
                        onLanguageChange = viewModel::setLanguage,
                        onThemeModeChange = viewModel::setThemeMode,
                        onWeightUnitChange = viewModel::setWeightUnit,
                        onHeightUnitChange = viewModel::setHeightUnit,
                        onClearAllHistory = viewModel::clearAllHistory,
                        onNavigateToAbout = { currentScreen = AppScreen.ABOUT }
                    )
                }
                AppScreen.ABOUT -> {
                    AboutScreen(
                        isBengali = isBengali,
                        onBack = { currentScreen = AppScreen.SETTINGS }
                    )
                }
            }
        }
    }
}
