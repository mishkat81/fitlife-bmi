package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val FitLifeLightColorScheme = lightColorScheme(
    primary = EmeraldGreenPrimary,
    onPrimary = Color.White,
    primaryContainer = MintGreenContainer,
    onPrimaryContainer = EmeraldGreenDark,
    secondary = TealAccent,
    onSecondary = Color.White,
    secondaryContainer = MintGreenLight,
    onSecondaryContainer = EmeraldGreenDark,
    tertiary = TealAccent,
    onTertiary = Color.White,
    background = LightBackground,
    onBackground = LightOnBackground,
    surface = LightSurface,
    onSurface = LightOnSurface,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = LightOnSurfaceVariant,
    outline = LightOutline
)

private val FitLifeDarkColorScheme = darkColorScheme(
    primary = DarkPrimary,
    onPrimary = Color(0xFF003827),
    primaryContainer = DarkPrimaryContainer,
    onPrimaryContainer = MintGreenLight,
    secondary = TealAccent,
    onSecondary = Color(0xFF003827),
    secondaryContainer = DarkSurfaceVariant,
    onSecondaryContainer = DarkOnSurface,
    tertiary = DarkPrimary,
    onTertiary = Color(0xFF003827),
    background = DarkBackground,
    onBackground = DarkOnBackground,
    surface = DarkSurface,
    onSurface = DarkOnSurface,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkOnSurfaceVariant,
    outline = DarkOutline
)

@Composable
fun FitLifeTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) FitLifeDarkColorScheme else FitLifeLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = FitLifeTypography,
        content = content
    )
}
