package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Brand Colors
val EmeraldGreenPrimary = Color(0xFF087F5B)
val EmeraldGreenDark = Color(0xFF054B36)
val MintGreenContainer = Color(0xFFDDF7E9)
val MintGreenLight = Color(0xFFE6FCF5)
val TealAccent = Color(0xFF20C997)

// Light Palette
val LightBackground = Color(0xFFF7FAF8)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEAF4EF)
val LightOnBackground = Color(0xFF132B21)
val LightOnSurface = Color(0xFF132B21)
val LightOnSurfaceVariant = Color(0xFF405D51)
val LightOutline = Color(0xFFC7DFD4)

// Dark Palette
val DarkBackground = Color(0xFF0B1612)
val DarkSurface = Color(0xFF13231D)
val DarkSurfaceVariant = Color(0xFF1C342B)
val DarkPrimary = Color(0xFF63E6BE)
val DarkPrimaryContainer = Color(0xFF087F5B)
val DarkOnBackground = Color(0xFFE5EDE9)
val DarkOnSurface = Color(0xFFE5EDE9)
val DarkOnSurfaceVariant = Color(0xFFA5C3B7)
val DarkOutline = Color(0xFF2F4D41)

// BMI Category Specific Colors
val BmiUnderweightColor = Color(0xFF339AF0) // Vibrant Sky Blue
val BmiNormalColor = Color(0xFF087F5B)      // Emerald Green
val BmiOverweightColor = Color(0xFFFD7E14)  // Warm Orange
val BmiObeseColor = Color(0xFFFA5252)       // Soft Crimson Red

// Developer Accent
val DeveloperCardBg = Color(0xFF065A41)
val DeveloperPhoneGreen = Color(0xFF25D366)
