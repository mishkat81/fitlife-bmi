package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.database.BmiRecord
import com.example.domain.calculator.BmiCalculator
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class TrendTimeFilter(val days: Int?, val labelEn: String, val labelBn: String) {
    SEVEN_DAYS(7, "7 Days", "৭ দিন"),
    THIRTY_DAYS(30, "30 Days", "৩০ দিন"),
    NINETY_DAYS(90, "90 Days", "৯০ দিন"),
    ALL_TIME(null, "All Time", "সব সময়")
}

enum class MetricType(val labelEn: String, val labelBn: String, val unitEn: String, val unitBn: String) {
    BMI("BMI Progress", "BMI অগ্রগতি", "BMI", "BMI"),
    WEIGHT("Weight Progress", "ওজন পরিবর্তন", "kg", "কেজি")
}

@Composable
fun BmiTrendChart(
    records: List<BmiRecord>,
    isBengali: Boolean,
    modifier: Modifier = Modifier
) {
    var selectedMetric by remember { mutableStateOf(MetricType.BMI) }
    var selectedFilter by remember { mutableStateOf(TrendTimeFilter.ALL_TIME) }

    // Filter records by timestamp
    val now = System.currentTimeMillis()
    val filteredRecords = remember(records, selectedFilter) {
        val days = selectedFilter.days
        if (days == null) {
            records.sortedBy { it.timestamp }
        } else {
            val threshold = now - (days * 24L * 60L * 60L * 1000L)
            records.filter { it.timestamp >= threshold }.sortedBy { it.timestamp }
        }
    }

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Metric Switch Tabs (BMI vs Weight)
            TabRow(
                selectedTabIndex = if (selectedMetric == MetricType.BMI) 0 else 1,
                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                contentColor = MaterialTheme.colorScheme.primary,
                modifier = Modifier.clipToBounds()
            ) {
                Tab(
                    selected = selectedMetric == MetricType.BMI,
                    onClick = { selectedMetric = MetricType.BMI },
                    text = {
                        Text(
                            text = if (isBengali) MetricType.BMI.labelBn else MetricType.BMI.labelEn,
                            fontWeight = if (selectedMetric == MetricType.BMI) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                )
                Tab(
                    selected = selectedMetric == MetricType.WEIGHT,
                    onClick = { selectedMetric = MetricType.WEIGHT },
                    text = {
                        Text(
                            text = if (isBengali) MetricType.WEIGHT.labelBn else MetricType.WEIGHT.labelEn,
                            fontWeight = if (selectedMetric == MetricType.WEIGHT) FontWeight.Bold else FontWeight.Medium
                        )
                    }
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Time Filter Chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TrendTimeFilter.entries.forEach { filter ->
                    FilterChip(
                        selected = selectedFilter == filter,
                        onClick = { selectedFilter = filter },
                        label = {
                            Text(
                                text = if (isBengali) filter.labelBn else filter.labelEn,
                                fontSize = 11.sp
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Check if we have enough points to chart
            if (filteredRecords.size < 2) {
                // Attractive empty state
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .background(
                            MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                            RoundedCornerShape(16.dp)
                        )
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primaryContainer,
                            modifier = Modifier.size(48.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.TrendingUp,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = if (isBengali) "পর্যাপ্ত রেকর্ড নেই" else "Insufficient Data",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (isBengali) {
                                "প্রবণতা চার্ট দেখতে অন্তত ২টি BMI পরিমাপ সংরক্ষণ করুন।"
                            } else {
                                "Save at least 2 BMI measurements to view your trend line chart."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                // Statistics Summary Card
                val values = filteredRecords.map {
                    if (selectedMetric == MetricType.BMI) it.bmiValue else it.weightKg
                }
                val firstVal = values.first()
                val lastVal = values.last()
                val minVal = values.minOrNull() ?: firstVal
                val maxVal = values.maxOrNull() ?: firstVal
                val diff = lastVal - firstVal

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    StatBox(
                        title = if (isBengali) "বর্তমান" else "Current",
                        value = "${BmiCalculator.formatNumber(lastVal, isBengali)} ${if (isBengali) selectedMetric.unitBn else selectedMetric.unitEn}"
                    )
                    StatBox(
                        title = if (isBengali) "পরিবর্তন" else "Change",
                        value = "${if (diff > 0) "+" else ""}${BmiCalculator.formatNumber(diff, isBengali)} ${if (isBengali) selectedMetric.unitBn else selectedMetric.unitEn}",
                        valueColor = if (diff < 0) Color(0xFF2B8A3E) else if (diff > 0) Color(0xFFD9480F) else MaterialTheme.colorScheme.onSurface
                    )
                    StatBox(
                        title = if (isBengali) "সর্বনিম্ন" else "Lowest",
                        value = "${BmiCalculator.formatNumber(minVal, isBengali)}"
                    )
                    StatBox(
                        title = if (isBengali) "সর্বোচ্চ" else "Highest",
                        value = "${BmiCalculator.formatNumber(maxVal, isBengali)}"
                    )
                }

                // Smooth Canvas Line Chart
                val primaryColor = MaterialTheme.colorScheme.primary
                val gridColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .padding(horizontal = 8.dp)
                ) {
                    Canvas(modifier = Modifier.fillMaxWidth().height(180.dp)) {
                        val canvasWidth = size.width
                        val canvasHeight = size.height

                        val paddingLeft = 30f
                        val paddingRight = 30f
                        val paddingTop = 20f
                        val paddingBottom = 30f

                        val plotWidth = canvasWidth - paddingLeft - paddingRight
                        val plotHeight = canvasHeight - paddingTop - paddingBottom

                        val yMin = (minVal - 1.0).coerceAtLeast(0.0)
                        val yMax = maxVal + 1.0
                        val yRange = if (yMax == yMin) 1.0 else (yMax - yMin)

                        // Draw 3 horizontal gridlines
                        for (i in 0..2) {
                            val gridY = paddingTop + (plotHeight / 2f) * i
                            drawLine(
                                color = gridColor,
                                start = Offset(paddingLeft, gridY),
                                end = Offset(canvasWidth - paddingRight, gridY),
                                strokeWidth = 1.dp.toPx()
                            )
                        }

                        // Calculate points
                        val points = filteredRecords.mapIndexed { index, record ->
                            val v = if (selectedMetric == MetricType.BMI) record.bmiValue else record.weightKg
                            val x = paddingLeft + (index.toFloat() / (filteredRecords.size - 1).coerceAtLeast(1)) * plotWidth
                            val y = paddingTop + plotHeight - (((v - yMin) / yRange) * plotHeight).toFloat()
                            Offset(x, y)
                        }

                        // Build line path & fill gradient path
                        val linePath = Path()
                        val fillPath = Path()

                        fillPath.moveTo(points.first().x, paddingTop + plotHeight)

                        points.forEachIndexed { index, point ->
                            if (index == 0) {
                                linePath.moveTo(point.x, point.y)
                                fillPath.lineTo(point.x, point.y)
                            } else {
                                val prev = points[index - 1]
                                val controlX1 = (prev.x + point.x) / 2f
                                val controlY1 = prev.y
                                val controlX2 = (prev.x + point.x) / 2f
                                val controlY2 = point.y
                                linePath.cubicTo(controlX1, controlY1, controlX2, controlY2, point.x, point.y)
                                fillPath.cubicTo(controlX1, controlY1, controlX2, controlY2, point.x, point.y)
                            }
                        }

                        fillPath.lineTo(points.last().x, paddingTop + plotHeight)
                        fillPath.close()

                        // Draw Fill Gradient
                        drawPath(
                            path = fillPath,
                            brush = Brush.verticalGradient(
                                colors = listOf(primaryColor.copy(alpha = 0.28f), Color.Transparent),
                                startY = paddingTop,
                                endY = paddingTop + plotHeight
                            )
                        )

                        // Draw Main Line
                        drawPath(
                            path = linePath,
                            color = primaryColor,
                            style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
                        )

                        // Draw Point Circles
                        points.forEach { pt ->
                            drawCircle(
                                color = primaryColor,
                                radius = 4.5.dp.toPx(),
                                center = pt
                            )
                            drawCircle(
                                color = Color.White,
                                radius = 2.5.dp.toPx(),
                                center = pt
                            )
                        }
                    }
                }

                // X-Axis Date Range Indicators
                val firstDate = SimpleDateFormat("dd MMM", Locale.getDefault()).format(Date(filteredRecords.first().timestamp))
                val lastDate = SimpleDateFormat("dd MMM", Locale.getDefault()).format(Date(filteredRecords.last().timestamp))

                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = if (isBengali) BmiCalculator.toBengaliDigits(firstDate) else firstDate,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = if (isBengali) BmiCalculator.toBengaliDigits(lastDate) else lastDate,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun StatBox(
    title: String,
    value: String,
    valueColor: Color = MaterialTheme.colorScheme.onSurface
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text(
            text = value,
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = valueColor
        )
    }
}

private fun Modifier.clipToBounds(): Modifier = this
