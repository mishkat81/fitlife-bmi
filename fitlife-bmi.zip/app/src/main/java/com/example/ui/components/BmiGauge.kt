package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.calculator.BmiCalculator
import com.example.domain.calculator.BmiCategory
import com.example.ui.theme.BmiNormalColor
import com.example.ui.theme.BmiObeseColor
import com.example.ui.theme.BmiOverweightColor
import com.example.ui.theme.BmiUnderweightColor
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun BmiGauge(
    bmi: Double,
    category: BmiCategory,
    isBengali: Boolean,
    modifier: Modifier = Modifier
) {
    // Gauge ranges from BMI 15.0 to 40.0 (total range 25 units)
    val minBmi = 15.0
    val maxBmi = 40.0
    val clampedBmi = bmi.coerceIn(minBmi, maxBmi)

    // Animated target progress: 0.0 to 1.0 corresponding to 180 degree arc
    val targetFraction = ((clampedBmi - minBmi) / (maxBmi - minBmi)).toFloat()
    val animatedProgress = remember { Animatable(0f) }

    LaunchedEffect(bmi) {
        animatedProgress.animateTo(
            targetValue = targetFraction,
            animationSpec = tween(durationMillis = 1100, easing = FastOutSlowInEasing)
        )
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(top = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier.size(240.dp, 135.dp),
                contentAlignment = Alignment.BottomCenter
            ) {
                val gaugeBgColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                val needleColor = MaterialTheme.colorScheme.onSurface

                Canvas(modifier = Modifier.size(240.dp, 135.dp)) {
                    val strokeWidth = 22.dp.toPx()
                    val arcWidth = size.width - strokeWidth
                    val arcHeight = (size.height * 2) - strokeWidth
                    val topLeft = Offset(strokeWidth / 2, strokeWidth / 2)
                    val arcSize = Size(arcWidth, arcHeight)

                    // Draw Background Arc (180 degrees from 180 to 0)
                    drawArc(
                        color = gaugeBgColor,
                        startAngle = 180f,
                        sweepAngle = 180f,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                    )

                    // Total range = 25.0
                    // Underweight: 15 to 18.5 (3.5 units -> 3.5/25 * 180 = 25.2 deg)
                    // Normal: 18.5 to 25.0 (6.5 units -> 6.5/25 * 180 = 46.8 deg)
                    // Overweight: 25.0 to 30.0 (5.0 units -> 5.0/25 * 180 = 36.0 deg)
                    // Obese: 30.0 to 40.0 (10.0 units -> 10.0/25 * 180 = 72.0 deg)

                    val degUnderweight = (3.5f / 25f) * 180f
                    val degNormal = (6.5f / 25f) * 180f
                    val degOverweight = (5.0f / 25f) * 180f
                    val degObese = (10.0f / 25f) * 180f

                    // 1. Underweight Segment
                    drawArc(
                        color = BmiUnderweightColor,
                        startAngle = 180f,
                        sweepAngle = degUnderweight,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = strokeWidth)
                    )

                    // 2. Normal Segment
                    drawArc(
                        color = BmiNormalColor,
                        startAngle = 180f + degUnderweight,
                        sweepAngle = degNormal,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = strokeWidth)
                    )

                    // 3. Overweight Segment
                    drawArc(
                        color = BmiOverweightColor,
                        startAngle = 180f + degUnderweight + degNormal,
                        sweepAngle = degOverweight,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = strokeWidth)
                    )

                    // 4. Obese Segment
                    drawArc(
                        color = BmiObeseColor,
                        startAngle = 180f + degUnderweight + degNormal + degOverweight,
                        sweepAngle = degObese,
                        useCenter = false,
                        topLeft = topLeft,
                        size = arcSize,
                        style = Stroke(width = strokeWidth)
                    )

                    // Needle pointer calculation
                    val currentAngle = 180f + (animatedProgress.value * 180f)
                    val angleRad = (currentAngle * PI / 180f).toFloat()
                    val center = Offset(size.width / 2, size.height)
                    val needleLength = (size.width / 2) - strokeWidth - 6.dp.toPx()

                    val needleEnd = Offset(
                        x = center.x + (needleLength * cos(angleRad)),
                        y = center.y + (needleLength * sin(angleRad))
                    )

                    // Draw needle line
                    drawLine(
                        color = needleColor,
                        start = center,
                        end = needleEnd,
                        strokeWidth = 3.5.dp.toPx(),
                        cap = StrokeCap.Round
                    )

                    // Center pivot circle
                    drawCircle(
                        color = needleColor,
                        radius = 8.dp.toPx(),
                        center = center
                    )
                    drawCircle(
                        color = Color.White,
                        radius = 4.dp.toPx(),
                        center = center
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Large BMI number
            Text(
                text = BmiCalculator.formatNumber(bmi, isBengali),
                style = MaterialTheme.typography.displayMedium,
                fontWeight = FontWeight.Bold,
                color = category.color
            )

            // Category Badge Pill
            Surface(
                shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
                color = category.color.copy(alpha = 0.15f),
                modifier = Modifier.padding(top = 4.dp)
            ) {
                Text(
                    text = if (isBengali) category.nameBn else category.nameEn,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = category.color,
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 5.dp)
                )
            }
        }
    }
}
