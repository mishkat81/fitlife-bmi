package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.database.BmiRecord
import com.example.data.preferences.AppLanguage
import com.example.data.preferences.HeightUnit
import com.example.data.preferences.ThemeMode
import com.example.data.preferences.UserPreferences
import com.example.data.preferences.UserPreferencesRepository
import com.example.data.preferences.WeightUnit
import com.example.data.repository.BmiRepository
import com.example.domain.calculator.BmiCalculator
import com.example.domain.calculator.BmiCategory
import com.example.pdf.BmiPdfGenerator
import java.io.File
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class BmiCalculationResult(
    val age: Int,
    val gender: String,
    val weightKg: Double,
    val heightCm: Double,
    val bmiValue: Double,
    val category: BmiCategory,
    val minHealthyWeightKg: Double,
    val maxHealthyWeightKg: Double,
    val timestamp: Long = System.currentTimeMillis()
)

data class CalculatorUiState(
    val ageInput: String = "25",
    val gender: String = "male", // "male" or "female"
    val weightInput: String = "70",
    val heightCmInput: String = "170",
    val heightFeetInput: String = "5",
    val heightInchesInput: String = "7",
    val weightUnit: WeightUnit = WeightUnit.KG,
    val heightUnit: HeightUnit = HeightUnit.CM,
    val result: BmiCalculationResult? = null,
    val errorMessage: String? = null,
    val isUnder18: Boolean = false,
    val isSaved: Boolean = false
)

class BmiViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application)
    private val repository = BmiRepository(database.bmiDao())
    private val preferencesRepository = UserPreferencesRepository(application)

    // User Preferences Flow
    val userPreferences: StateFlow<UserPreferences> = preferencesRepository.userPreferencesFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = UserPreferences()
        )

    // Sort order for records: true = newest first, false = oldest first
    private val _sortDescending = MutableStateFlow(true)
    val sortDescending: StateFlow<Boolean> = _sortDescending.asStateFlow()

    // Observe Room database records with current sort order
    val records: StateFlow<List<BmiRecord>> = combine(
        repository.getAllRecords(descending = true),
        _sortDescending
    ) { all, desc ->
        if (desc) all.sortedByDescending { it.timestamp } else all.sortedBy { it.timestamp }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Calculator State
    private val _calculatorState = MutableStateFlow(CalculatorUiState())
    val calculatorState: StateFlow<CalculatorUiState> = _calculatorState.asStateFlow()

    init {
        // Sync default units from preferences
        viewModelScope.launch {
            userPreferences.collect { prefs ->
                _calculatorState.update { current ->
                    current.copy(
                        weightUnit = prefs.weightUnit,
                        heightUnit = prefs.heightUnit
                    )
                }
            }
        }
    }

    fun updateAge(age: String) {
        _calculatorState.update { it.copy(ageInput = age, errorMessage = null) }
    }

    fun updateGender(gender: String) {
        _calculatorState.update { it.copy(gender = gender) }
    }

    fun updateWeight(weight: String) {
        _calculatorState.update { it.copy(weightInput = weight, errorMessage = null) }
    }

    fun updateHeightCm(height: String) {
        _calculatorState.update { it.copy(heightCmInput = height, errorMessage = null) }
    }

    fun updateHeightFeet(feet: String) {
        _calculatorState.update { it.copy(heightFeetInput = feet, errorMessage = null) }
    }

    fun updateHeightInches(inches: String) {
        _calculatorState.update { it.copy(heightInchesInput = inches, errorMessage = null) }
    }

    fun setWeightUnit(unit: WeightUnit) {
        val current = _calculatorState.value
        if (current.weightUnit == unit) return

        // Convert current numeric value for user convenience
        val currentWeight = current.weightInput.toDoubleOrNull()
        val convertedWeight = if (currentWeight != null && currentWeight > 0) {
            if (unit == WeightUnit.LB) {
                BmiCalculator.kgToLb(currentWeight).toString()
            } else {
                BmiCalculator.lbToKg(currentWeight).toString()
            }
        } else current.weightInput

        _calculatorState.update {
            it.copy(
                weightUnit = unit,
                weightInput = convertedWeight
            )
        }
        viewModelScope.launch {
            preferencesRepository.setWeightUnit(unit)
        }
    }

    fun setHeightUnit(unit: HeightUnit) {
        val current = _calculatorState.value
        if (current.heightUnit == unit) return

        if (unit == HeightUnit.FT_IN) {
            val cm = current.heightCmInput.toDoubleOrNull()
            if (cm != null && cm > 0) {
                val (ft, inch) = BmiCalculator.cmToFeetInches(cm)
                _calculatorState.update {
                    it.copy(
                        heightUnit = unit,
                        heightFeetInput = ft.toString(),
                        heightInchesInput = inch.toString()
                    )
                }
            } else {
                _calculatorState.update { it.copy(heightUnit = unit) }
            }
        } else {
            val ft = current.heightFeetInput.toIntOrNull() ?: 0
            val inch = current.heightInchesInput.toDoubleOrNull() ?: 0.0
            if (ft > 0 || inch > 0.0) {
                val cm = BmiCalculator.feetInchesToCm(ft, inch)
                _calculatorState.update {
                    it.copy(
                        heightUnit = unit,
                        heightCmInput = cm.toInt().toString()
                    )
                }
            } else {
                _calculatorState.update { it.copy(heightUnit = unit) }
            }
        }
        viewModelScope.launch {
            preferencesRepository.setHeightUnit(unit)
        }
    }

    fun calculateBmi() {
        val state = _calculatorState.value
        val age = state.ageInput.toIntOrNull()
        if (age == null || age <= 0 || age > 130) {
            _calculatorState.update {
                it.copy(errorMessage = "Please enter a valid age (1-130)")
            }
            return
        }

        val rawWeight = state.weightInput.toDoubleOrNull()
        if (rawWeight == null || rawWeight <= 0.0 || rawWeight > 500.0) {
            _calculatorState.update {
                it.copy(errorMessage = "Please enter a valid weight")
            }
            return
        }

        val weightKg = if (state.weightUnit == WeightUnit.LB) {
            BmiCalculator.lbToKg(rawWeight)
        } else {
            rawWeight
        }

        val heightCm = if (state.heightUnit == HeightUnit.FT_IN) {
            val ft = state.heightFeetInput.toIntOrNull() ?: 0
            val inch = state.heightInchesInput.toDoubleOrNull() ?: 0.0
            if (ft <= 0 && inch <= 0) {
                _calculatorState.update {
                    it.copy(errorMessage = "Please enter valid feet and inches")
                }
                return
            }
            BmiCalculator.feetInchesToCm(ft, inch)
        } else {
            val cm = state.heightCmInput.toDoubleOrNull()
            if (cm == null || cm < 40.0 || cm > 260.0) {
                _calculatorState.update {
                    it.copy(errorMessage = "Please enter a valid height in cm (40-260)")
                }
                return
            }
            cm
        }

        val bmi = BmiCalculator.calculateBmi(weightKg, heightCm)
        val category = BmiCalculator.getCategory(bmi)
        val healthyRange = BmiCalculator.calculateHealthyWeightRange(heightCm)

        val isUnder18 = age < 18

        val result = BmiCalculationResult(
            age = age,
            gender = state.gender,
            weightKg = weightKg,
            heightCm = heightCm,
            bmiValue = bmi,
            category = category,
            minHealthyWeightKg = healthyRange.first,
            maxHealthyWeightKg = healthyRange.second
        )

        _calculatorState.update {
            it.copy(
                result = result,
                errorMessage = null,
                isUnder18 = isUnder18,
                isSaved = false
            )
        }
    }

    fun resetCalculator() {
        _calculatorState.update {
            CalculatorUiState(
                weightUnit = it.weightUnit,
                heightUnit = it.heightUnit
            )
        }
    }

    fun saveCurrentResult() {
        val result = _calculatorState.value.result ?: return
        viewModelScope.launch {
            repository.insertRecord(
                BmiRecord(
                    timestamp = result.timestamp,
                    age = result.age,
                    gender = result.gender,
                    weightKg = result.weightKg,
                    heightCm = result.heightCm,
                    bmiValue = result.bmiValue,
                    categoryKey = result.category.key
                )
            )
            _calculatorState.update { it.copy(isSaved = true) }
        }
    }

    fun deleteRecord(id: Long) {
        viewModelScope.launch {
            repository.deleteRecord(id)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            repository.clearAll()
        }
    }

    fun toggleSortOrder() {
        _sortDescending.update { !it }
    }

    fun setLanguage(language: AppLanguage) {
        viewModelScope.launch {
            preferencesRepository.setLanguage(language)
        }
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch {
            preferencesRepository.setThemeMode(mode)
        }
    }

    fun generatePdf(isBengali: Boolean): File? {
        val result = _calculatorState.value.result ?: return null
        return try {
            BmiPdfGenerator.generateBmiReport(
                context = getApplication(),
                age = result.age,
                gender = result.gender,
                weightKg = result.weightKg,
                heightCm = result.heightCm,
                bmiValue = result.bmiValue,
                category = result.category,
                isBengali = isBengali
            )
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
