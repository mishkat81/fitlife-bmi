package com.example.pdf

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import androidx.core.content.res.ResourcesCompat
import com.example.R
import com.example.domain.calculator.BmiCalculator
import com.example.domain.calculator.BmiCategory
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object BmiPdfGenerator {

    fun generateBmiReport(
        context: Context,
        age: Int,
        gender: String,
        weightKg: Double,
        heightCm: Double,
        bmiValue: Double,
        category: BmiCategory,
        isBengali: Boolean
    ): File {
        val pdfDocument = PdfDocument()

        // Standard A4 dimensions in points (72 points per inch)
        val pageWidth = 595
        val pageHeight = 842
        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas: Canvas = page.canvas

        // Fonts
        val customTypeface: Typeface? = try {
            ResourcesCompat.getFont(context, R.font.hind_siliguri)
        } catch (e: Exception) {
            Typeface.DEFAULT
        }
        val boldTypeface = if (customTypeface != null) {
            Typeface.create(customTypeface, Typeface.BOLD)
        } else Typeface.DEFAULT_BOLD

        val normalTypeface = customTypeface ?: Typeface.DEFAULT

        // Paints
        val paint = Paint().apply {
            isAntiAlias = true
        }

        // Draw top emerald header banner
        paint.color = Color.parseColor("#087F5B")
        paint.style = Paint.Style.FILL
        canvas.drawRect(0f, 0f, pageWidth.toFloat(), 110f, paint)

        // Accent strip
        paint.color = Color.parseColor("#20C997")
        canvas.drawRect(0f, 110f, pageWidth.toFloat(), 116f, paint)

        // Header Title
        paint.color = Color.WHITE
        paint.typeface = boldTypeface
        paint.textSize = 28f
        val headerTitle = if (isBengali) "FitLife BMI — স্বাস্থ্য প্রতিবেদন" else "FitLife BMI — Health Report"
        canvas.drawText(headerTitle, 36f, 52f, paint)

        // Tagline
        paint.typeface = normalTypeface
        paint.textSize = 14f
        paint.color = Color.parseColor("#E6FCF5")
        val tagline = if (isBengali) "আপনার BMI জানুন, সুস্থ জীবন গড়ুন।" else "Know Your BMI, Improve Your Lifestyle."
        canvas.drawText(tagline, 36f, 82f, paint)

        // Report Generation Date & Time
        val dateFormat = SimpleDateFormat("dd MMMM yyyy, hh:mm a", Locale.getDefault())
        val dateStr = dateFormat.format(Date())
        paint.textSize = 11f
        paint.color = Color.parseColor("#DDF7E9")
        val dateLabel = if (isBengali) "তারিখ: ${BmiCalculator.toBengaliDigits(dateStr)}" else "Generated: $dateStr"
        val dateWidth = paint.measureText(dateLabel)
        canvas.drawText(dateLabel, pageWidth - 36f - dateWidth, 82f, paint)

        var currentY = 150f

        // Category Card Background
        val categoryBgColor = when (category) {
            BmiCategory.UNDERWEIGHT -> Color.parseColor("#E7F5FF")
            BmiCategory.NORMAL -> Color.parseColor("#DDF7E9")
            BmiCategory.OVERWEIGHT -> Color.parseColor("#FFF4E6")
            BmiCategory.OBESE -> Color.parseColor("#FFE3E3")
        }
        val categoryTextColor = when (category) {
            BmiCategory.UNDERWEIGHT -> Color.parseColor("#1971C2")
            BmiCategory.NORMAL -> Color.parseColor("#087F5B")
            BmiCategory.OVERWEIGHT -> Color.parseColor("#D9480F")
            BmiCategory.OBESE -> Color.parseColor("#C92A2A")
        }

        paint.color = categoryBgColor
        paint.style = Paint.Style.FILL
        val cardRect = RectF(36f, currentY, pageWidth - 36f, currentY + 115f)
        canvas.drawRoundRect(cardRect, 16f, 16f, paint)

        // Border around category card
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.5f
        paint.color = categoryTextColor
        canvas.drawRoundRect(cardRect, 16f, 16f, paint)

        // Reset to FILL
        paint.style = Paint.Style.FILL

        // Inside Category Card: BMI Score Label
        paint.typeface = normalTypeface
        paint.textSize = 13f
        paint.color = Color.parseColor("#495057")
        val bmiScoreTitle = if (isBengali) "আপনার বডি মাস ইনডেক্স (BMI)" else "Your Body Mass Index (BMI)"
        canvas.drawText(bmiScoreTitle, 60f, currentY + 36f, paint)

        // Large BMI Score
        paint.typeface = boldTypeface
        paint.textSize = 42f
        paint.color = categoryTextColor
        val bmiScoreValue = BmiCalculator.formatNumber(bmiValue, isBengali)
        canvas.drawText(bmiScoreValue, 60f, currentY + 84f, paint)

        // Category Badge on the right
        val categoryLabel = if (isBengali) category.nameBn else category.nameEn
        paint.textSize = 20f
        paint.typeface = boldTypeface
        paint.color = categoryTextColor
        val catWidth = paint.measureText(categoryLabel)
        canvas.drawText(categoryLabel, pageWidth - 60f - catWidth, currentY + 62f, paint)

        paint.textSize = 12f
        paint.typeface = normalTypeface
        paint.color = Color.parseColor("#495057")
        val refRangeText = if (isBengali) "আদর্শ BMI পরিসীমা: ১৮.৫ – ২৪.৯" else "Healthy Reference: 18.5 – 24.9"
        val refWidth = paint.measureText(refRangeText)
        canvas.drawText(refRangeText, pageWidth - 60f - refWidth, currentY + 86f, paint)

        currentY += 140f

        // Section: Personal Metrics Grid
        paint.typeface = boldTypeface
        paint.textSize = 17f
        paint.color = Color.parseColor("#212529")
        val metricsHeader = if (isBengali) "শারীরিক তথ্যাবলী" else "Physical Assessment Metrics"
        canvas.drawText(metricsHeader, 36f, currentY, paint)

        currentY += 15f

        // Metrics Table / Box
        paint.color = Color.parseColor("#F8F9FA")
        paint.style = Paint.Style.FILL
        val tableRect = RectF(36f, currentY, pageWidth - 36f, currentY + 140f)
        canvas.drawRoundRect(tableRect, 12f, 12f, paint)

        paint.color = Color.parseColor("#DEE2E6")
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        canvas.drawRoundRect(tableRect, 12f, 12f, paint)
        paint.style = Paint.Style.FILL

        // Table Rows
        val healthyRange = BmiCalculator.calculateHealthyWeightRange(heightCm)
        val minHealthy = BmiCalculator.formatNumber(healthyRange.first, isBengali)
        val maxHealthy = BmiCalculator.formatNumber(healthyRange.second, isBengali)

        val genderLabel = if (isBengali) {
            if (gender.lowercase() == "female") "মহিলা" else "পুরুষ"
        } else {
            gender.replaceFirstChar { it.uppercase() }
        }

        val rows = listOf(
            Pair(if (isBengali) "বয়স" else "Age", if (isBengali) "${BmiCalculator.toBengaliDigits(age.toString())} বছর" else "$age years"),
            Pair(if (isBengali) "লিঙ্গ" else "Gender", genderLabel),
            Pair(if (isBengali) "ওজন" else "Weight", "${BmiCalculator.formatNumber(weightKg, isBengali)} ${if (isBengali) "কেজি" else "kg"}"),
            Pair(if (isBengali) "উচ্চতা" else "Height", "${BmiCalculator.formatNumber(heightCm, isBengali)} ${if (isBengali) "সেমি" else "cm"}"),
            Pair(if (isBengali) "প্রত্যাশিত আদর্শ ওজন" else "Estimated Healthy Weight Range", "$minHealthy – $maxHealthy ${if (isBengali) "কেজি" else "kg"}")
        )

        var rowY = currentY + 28f
        rows.forEach { (label, value) ->
            paint.typeface = normalTypeface
            paint.textSize = 12f
            paint.color = Color.parseColor("#495057")
            canvas.drawText(label, 56f, rowY, paint)

            paint.typeface = boldTypeface
            paint.textSize = 12f
            paint.color = Color.parseColor("#212529")
            val valWidth = paint.measureText(value)
            canvas.drawText(value, pageWidth - 56f - valWidth, rowY, paint)

            rowY += 23f
        }

        currentY += 165f

        // Health Explanation & Advice Section
        paint.typeface = boldTypeface
        paint.textSize = 17f
        paint.color = Color.parseColor("#212529")
        val adviceHeader = if (isBengali) "স্বাস্থ্য বিশ্লেষণ ও পরামর্শ" else "Health Assessment & Guidance"
        canvas.drawText(adviceHeader, 36f, currentY, paint)

        currentY += 18f

        // Advice Box
        paint.color = Color.parseColor("#FFFFFF")
        paint.style = Paint.Style.FILL
        val adviceBox = RectF(36f, currentY, pageWidth - 36f, currentY + 110f)
        canvas.drawRoundRect(adviceBox, 12f, 12f, paint)

        paint.color = Color.parseColor("#CED4DA")
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1f
        canvas.drawRoundRect(adviceBox, 12f, 12f, paint)
        paint.style = Paint.Style.FILL

        paint.typeface = normalTypeface
        paint.textSize = 12f
        paint.color = Color.parseColor("#343A40")

        val adviceText = if (isBengali) category.adviceBn else category.adviceEn
        // Draw wrapped advice text
        drawMultilineText(
            canvas = canvas,
            paint = paint,
            text = adviceText,
            x = 52f,
            startY = currentY + 28f,
            maxWidth = pageWidth - 104f,
            lineSpacing = 19f
        )

        currentY += 135f

        // Disclaimer Section
        paint.typeface = normalTypeface
        paint.textSize = 10f
        paint.color = Color.parseColor("#868E96")
        val disclaimerText = if (isBengali) {
            "সতর্কবার্তা: BMI একটি স্ক্রিনিং সূচক মাত্র। এটি পেশি, চর্বি বা হাড়ের ঘনত্ব সরাসরি পরিমাপ করে না। কোনো স্বাস্থ্যগত সিদ্ধান্ত বা ডায়েট শুরুর পূর্বে বিশেষজ্ঞ চিকিৎসকের পরামর্শ নিন।"
        } else {
            "Medical Disclaimer: BMI is a general screening indicator and does not differentiate between body fat, muscle mass, or bone density. Please consult a qualified healthcare provider for personalized medical evaluation."
        }
        drawMultilineText(
            canvas = canvas,
            paint = paint,
            text = disclaimerText,
            x = 36f,
            startY = currentY,
            maxWidth = pageWidth - 72f,
            lineSpacing = 15f
        )

        // ==========================================
        // MANDATORY DEVELOPER BRANDING FOOTER
        // ==========================================
        val footerY = pageHeight - 65f

        // Thin separator line
        paint.color = Color.parseColor("#DEE2E6")
        paint.strokeWidth = 1f
        paint.style = Paint.Style.STROKE
        canvas.drawLine(36f, footerY - 12f, pageWidth - 36f, footerY - 12f, paint)
        paint.style = Paint.Style.FILL

        // Developer Brand: FitLife BMI
        paint.typeface = boldTypeface
        paint.textSize = 12f
        paint.color = Color.parseColor("#087F5B")
        canvas.drawText("FitLife BMI", 36f, footerY + 6f, paint)

        // Tagline under brand
        paint.typeface = normalTypeface
        paint.textSize = 9.5f
        paint.color = Color.parseColor("#6C757D")
        val footerTagline = if (isBengali) "আপনার BMI জানুন, সুস্থ জীবন গড়ুন।" else "Know Your BMI, Improve Your Lifestyle."
        canvas.drawText(footerTagline, 36f, footerY + 22f, paint)

        // Developer info on right: মিশকাত আহমদ | ০১৯১২৪২৫৮৩৬
        val devLine1 = if (isBengali) "অ্যাপ নির্মাতা: মিশকাত আহমদ" else "Developed by: মিশকাত আহমদ"
        val devLine2 = if (isBengali) "যোগাযোগ: ০১৯১২৪২৫৮৩৬" else "Contact: ০১৯১২৪২৫৮৩৬"

        paint.typeface = boldTypeface
        paint.textSize = 10.5f
        paint.color = Color.parseColor("#212529")
        val dev1Width = paint.measureText(devLine1)
        canvas.drawText(devLine1, pageWidth - 36f - dev1Width, footerY + 6f, paint)

        paint.typeface = normalTypeface
        paint.textSize = 10f
        paint.color = Color.parseColor("#087F5B")
        val dev2Width = paint.measureText(devLine2)
        canvas.drawText(devLine2, pageWidth - 36f - dev2Width, footerY + 22f, paint)

        pdfDocument.finishPage(page)

        // Save file to cache/reports/
        val reportsDir = File(context.cacheDir, "reports")
        if (!reportsDir.exists()) {
            reportsDir.mkdirs()
        }
        val timestamp = System.currentTimeMillis()
        val pdfFile = File(reportsDir, "FitLife_BMI_Report_$timestamp.pdf")
        val fos = FileOutputStream(pdfFile)
        pdfDocument.writeTo(fos)
        fos.flush()
        fos.close()
        pdfDocument.close()

        return pdfFile
    }

    private fun drawMultilineText(
        canvas: Canvas,
        paint: Paint,
        text: String,
        x: Float,
        startY: Float,
        maxWidth: Float,
        lineSpacing: Float
    ) {
        val words = text.split(" ")
        var currentLine = ""
        var currentY = startY

        for (word in words) {
            val testLine = if (currentLine.isEmpty()) word else "$currentLine $word"
            val testWidth = paint.measureText(testLine)
            if (testWidth > maxWidth && currentLine.isNotEmpty()) {
                canvas.drawText(currentLine, x, currentY, paint)
                currentLine = word
                currentY += lineSpacing
            } else {
                currentLine = testLine
            }
        }
        if (currentLine.isNotEmpty()) {
            canvas.drawText(currentLine, x, currentY, paint)
        }
    }

    fun sharePdf(context: Context, file: File) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(shareIntent, "Share FitLife BMI Report"))
    }

    fun openPdf(context: Context, file: File) {
        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            file
        )
        val viewIntent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/pdf")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(viewIntent)
        } catch (e: Exception) {
            // Fallback to sharing if no native PDF viewer is installed
            sharePdf(context, file)
        }
    }
}
