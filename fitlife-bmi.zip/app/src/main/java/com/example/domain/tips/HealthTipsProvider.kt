package com.example.domain.tips

enum class TipCategory(val key: String, val titleEn: String, val titleBn: String) {
    EATING("eating", "Healthy Eating", "স্বাস্থ্যকর খাদ্যাভ্যাস"),
    ACTIVITY("activity", "Physical Activity", "শারীরিক পরিশ্রম ও ব্যায়াম"),
    WEIGHT("weight", "Weight Management", "ওজন নিয়ন্ত্রণ কৌশল"),
    SLEEP("sleep", "Sleep & Lifestyle", "ঘুম ও মানসিক স্বাস্থ্য"),
    HYDRATION("hydration", "Hydration", "পর্যাপ্ত পানি পান")
}

data class HealthTip(
    val id: String,
    val category: TipCategory,
    val titleEn: String,
    val titleBn: String,
    val contentEn: String,
    val contentBn: String,
    val iconName: String
)

object HealthTipsProvider {

    val tips: List<HealthTip> = listOf(
        // Healthy Eating (5 tips)
        HealthTip(
            id = "eating_1",
            category = TipCategory.EATING,
            titleEn = "Fill Half Your Plate with Veggies",
            titleBn = "প্লেটের অর্ধেক শাকসবজি ও ফল রাখুন",
            contentEn = "Aim to make vegetables and fresh fruits take up half of your meal plate. They provide essential vitamins, minerals, and dietary fiber that keep you full longer without excess calories.",
            contentBn = "প্রতিবেলার খাবারের থালায় অর্ধেক শাকসবজি ও সালাদ রাখুন। এতে প্রয়োজনীয় ভিটামিন, খনিজ ও আঁশ থাকে যা কম ক্যালোরিতে পেট ভরিয়ে রাখে।",
            iconName = "restaurant"
        ),
        HealthTip(
            id = "eating_2",
            category = TipCategory.EATING,
            titleEn = "Choose Whole Grains Over Refined",
            titleBn = "লাল চাল ও লাল আটা বেছে নিন",
            contentEn = "Replace white rice and white flour with brown rice, whole wheat, oats, and millet. Whole grains release glucose slowly, preventing blood sugar spikes and mid-day crashes.",
            contentBn = "সাদা ভাতের বদলে লাল চালের ভাত এবং ময়দার বদলে লাল আটার রুটি খান। এটি ধীরগতিতে শক্তি জোগায় এবং রক্তে গ্লুকোজের আকস্মিক বৃদ্ধি রোধ করে।",
            iconName = "grain"
        ),
        HealthTip(
            id = "eating_3",
            category = TipCategory.EATING,
            titleEn = "Lean Protein with Every Meal",
            titleBn = "প্রতিবেলায় পর্যাপ্ত প্রোটিন রাখুন",
            contentEn = "Incorporate lentils (dal), eggs, fish, skinless poultry, or beans into your meals. Protein helps preserve lean muscle mass, supports repair, and reduces unnecessary hunger pangs.",
            contentBn = "মাছ, ডিম, ডাল, ছোলা কিংবা মুরগির মাংসের মতো প্রোটিন সমৃদ্ধ খাবার রাখুন। প্রোটিন পেশি গঠনে সাহায্য করে এবং অসময়ে ঘনঘন ক্ষুধা পাওয়া কমায়।",
            iconName = "egg"
        ),
        HealthTip(
            id = "eating_4",
            category = TipCategory.EATING,
            titleEn = "Cut Down Added Sugars & Sodas",
            titleBn = "অতিরিক্ত চিনি ও কোল্ড ড্রিংকস বর্জন করুন",
            contentEn = "Soft drinks, sweet tea, packaged juices, and sweets carry liquid calories with zero nutritional value. Replacing sugary beverages with water or infused lime water makes an immediate health difference.",
            contentBn = "কোমল পানীয়, অতিরিক্ত মিষ্টি চা এবং প্যাকেটজাত জুস এড়িয়ে চলুন। মিষ্টি পানীয়র বদলে সাধারণ পানি বা লেবু-পানি পান করুন।",
            iconName = "no_drinks"
        ),
        HealthTip(
            id = "eating_5",
            category = TipCategory.EATING,
            titleEn = "Practice Mindful Eating",
            titleBn = "মনোযোগ দিয়ে চিবিয়ে খাবার খান",
            contentEn = "Eat without mobile screens or televisions distracting you. Chew slowly and listen to your body's satiety signals. It takes about 20 minutes for your brain to register fullness.",
            contentBn = "টিভি বা স্মার্টফোন দেখতে দেখতে খাবার খাবেন না। খাবার ভালোমতো চিবিয়ে ধীরে ধীরে খান। পেট ভরার সংকেত মস্তিষ্কে পৌঁছাতে প্রায় ২০ মিনিট সময় লাগে।",
            iconName = "self_improvement"
        ),

        // Physical Activity (5 tips)
        HealthTip(
            id = "act_1",
            category = TipCategory.ACTIVITY,
            titleEn = "150 Minutes of Moderate Cardio Weekly",
            titleBn = "সপ্তাহে ১৫০ মিনিট মধ্যম গতির ব্যায়াম",
            contentEn = "Brisk walking, light jogging, cycling, or swimming for 30 minutes 5 days a week strengthens your heart, improves insulin sensitivity, and elevates mental mood.",
            contentBn = "সপ্তাহে অন্তত ৫ দিন প্রতিদিন ৩০ মিনিট করে দ্রুত হাঁটার চেষ্টা করুন। দ্রুত হাঁটা বা সাইক্লিং হৃদযন্ত্রকে সুস্থ রাখে ও মানসিক প্রফুল্লতা বাড়ায়।",
            iconName = "directions_walk"
        ),
        HealthTip(
            id = "act_2",
            category = TipCategory.ACTIVITY,
            titleEn = "Strength Training Twice a Week",
            titleBn = "সপ্তাহে ২ দিন সাধারণ শক্তিচর্চা",
            contentEn = "Bodyweight exercises like squats, push-ups, or using light dumbbells help maintain bone density and muscle mass, increasing resting metabolic rate.",
            contentBn = "বডি-ওয়েট স্কোয়াট, পুশ-আপ কিংবা সাধারণ স্ট্রেচিং সপ্তাহে অন্তত দু'দিন করুন। এটি শরীরের হাড় ও পেশিকে মজবুত করে এবং মেটাবলিজম বাড়ায়।",
            iconName = "fitness_center"
        ),
        HealthTip(
            id = "act_3",
            category = TipCategory.ACTIVITY,
            titleEn = "Break Up Sedentary Sitting",
            titleBn = "টানা বসে থাকার অভ্যাস ভাঙুন",
            contentEn = "If working at a desk, stand up every 45-60 minutes. Stretch, walk down the corridor, or take the stairs. Non-exercise activity thermogenesis (NEAT) adds up significantly.",
            contentBn = "অফিস বা পড়ার টেবিলে একটানা বসে না থেকে প্রতি ৪৫-৬০ মিনিট পর উঠে দাঁড়ান এবং ২ মিনিট পায়চারি করুন। লিফটের বদলে সিঁড়ি ব্যবহার করার অভ্যাস করুন।",
            iconName = "chair"
        ),
        HealthTip(
            id = "act_4",
            category = TipCategory.ACTIVITY,
            titleEn = "Find an Activity You Enjoy",
            titleBn = "আনন্দদায়ক শারীরিক কর্মকাণ্ড বেছে নিন",
            contentEn = "Consistency beats intensity. Whether it is gardening, dancing, badminton, or playing with your children, regular enjoyable movement creates sustainable habits.",
            contentBn = "ব্যায়ামকে বোঝা মনে না করে খেলাধুলা, সাইকেল চালানো বা বাগানের কাজ বেছে নিন যা নিয়মিত চালিয়ে যাওয়া আপনার জন্য আনন্দদায়ক হবে।",
            iconName = "sports_tennis"
        ),
        HealthTip(
            id = "act_5",
            category = TipCategory.ACTIVITY,
            titleEn = "Gentle Post-Meal Strolls",
            titleBn = "খাবারের পর ১০-১৫ মিনিটের হাঁটা",
            contentEn = "A gentle 10 to 15-minute walk after lunch or dinner aids digestion and significantly tempers postprandial blood glucose spikes.",
            contentBn = "ভারী খাবারের পরপরই বিছানায় শুয়ে না পড়ে ১০-১৫ মিনিট ধীরে ধীরে হাঁটার অভ্যাস করুন। এটি হজমে সাহায্য করে এবং রক্তে সুগার নিয়ন্ত্রণে রাখে।",
            iconName = "nature_people"
        ),

        // Weight Management (5 tips)
        HealthTip(
            id = "wm_1",
            category = TipCategory.WEIGHT,
            titleEn = "Focus on Habits, Not Quick Fixes",
            titleBn = "সাময়িক ক্র্যাশ ডায়েট এড়িয়ে স্থায়ী অভ্যাস গড়ুন",
            contentEn = "Extreme fad diets or rapid weight loss plans are difficult to sustain and often cause muscle loss. Aim for a gradual, steady change of 0.5 to 1 kg per week.",
            contentBn = "কঠিন কোনো ক্র্যাশ ডায়েটের পেছনে না ছুটে স্বাস্থ্যকর জীবনযাত্রার ছোট ছোট অভ্যাস স্থায়ীভাবে নিজের জীবনে যুক্ত করুন। ধীরে ধীরে টেকসই পরিবর্তন আসে।",
            iconName = "timeline"
        ),
        HealthTip(
            id = "wm_2",
            category = TipCategory.WEIGHT,
            titleEn = "Smart Portion Control",
            titleBn = "খাবারের পরিমাণের দিকে খেয়াল রাখুন",
            contentEn = "Using smaller bowls and plates can naturally help regulate portion sizes. Avoid taking second helpings unless you feel genuine physical hunger.",
            contentBn = "ছোট থালা বা বাটি ব্যবহার করলে অবচেতনভাবেই খাবারের পরিমাণ নিয়ন্ত্রণে থাকে। পেট ভরে গেলে অতিরিক্ত খাবার জোর করে খাবেন না।",
            iconName = "pie_chart"
        ),
        HealthTip(
            id = "wm_3",
            category = TipCategory.WEIGHT,
            titleEn = "Stock Healthy Snacks",
            titleBn = "স্বাস্থ্যকর নাশতা হাতের কাছে রাখুন",
            contentEn = "Keep fresh seasonal fruit, raw cucumber slices, roasted chickpeas, or a handful of nuts ready when cravings strike instead of chips, bakery biscuits, or deep-fried singaras.",
            contentBn = "বিকেলের নাস্তায় চিপস, চানাচুর বা ভাজাপোড়ার বদলে শসা, পেয়ারা, ভেজানো বা ভাজা ছোলা অথবা বাদাম খাওয়ার অভ্যাস করুন।",
            iconName = "apple"
        ),
        HealthTip(
            id = "wm_4",
            category = TipCategory.WEIGHT,
            titleEn = "Track Your Trends Periodically",
            titleBn = "সপ্তাহে নির্দিষ্ট দিনে ওজন মাপুন",
            contentEn = "Weigh yourself once a week at the same time (ideally in the morning after waking and using the bathroom). Day-to-day fluctuations due to water retention are normal.",
            contentBn = "প্রতিদিন না মেপে সপ্তাহে একবার সকালে খালি পেটে ওজন মাপুন। পানির ভারসাম্য বা লবণের কারণে দিনে দিনে কিছুটা তারতম্য হওয়া খুব স্বাভাবিক।",
            iconName = "monitor_weight"
        ),
        HealthTip(
            id = "wm_5",
            category = TipCategory.WEIGHT,
            titleEn = "Mindful Salt and Sodium Intake",
            titleBn = "লবণ ও অতিরিক্ত সোডিয়াম নিয়ন্ত্রণ করুন",
            contentEn = "Excess sodium promotes water retention and raises blood pressure. Avoid adding raw salt on cooked rice or curry, and limit processed snacks.",
            contentBn = "ভাতের সাথে কাঁচা লবণ খাওয়ার অভ্যাস পুরোপুরি বাদ দিন। প্রক্রিয়াজাত প্যাকেটজাত খাবারে অতিরিক্ত সোডিয়াম থাকে যা রক্তচাপ ও ওজন বাড়াতে পারে।",
            iconName = "grain"
        ),

        // Sleep & Lifestyle (5 tips)
        HealthTip(
            id = "sl_1",
            category = TipCategory.SLEEP,
            titleEn = "Prioritize 7-8 Hours of Nightly Sleep",
            titleBn = "প্রতি রাতে ৭-৮ ঘণ্টা নিয়মিত ঘুম",
            contentEn = "Sleep deprivation disrupts hunger hormones (leptin and ghrelin), which triggers intense cravings for sugar and fatty foods during the daytime.",
            contentBn = "ঘুমের ঘাটতি হলে শরীরে কর্টিসল ও ক্ষুধার হরমোনের ভারসাম্য নষ্ট হয়, ফলে মিষ্টি ও চর্বিযুক্ত খাবার খাওয়ার ইচ্ছা অনেক বেড়ে যায়।",
            iconName = "bedtime"
        ),
        HealthTip(
            id = "sl_2",
            category = TipCategory.SLEEP,
            titleEn = "Digital Sunset 45 Mins Before Bed",
            titleBn = "ঘুমানোর ৪৫ মিনিট আগে মোবাইল স্ক্রিন বন্ধ",
            contentEn = "Blue light from phone and computer screens suppresses melatonin production. Put down devices and unwind with reading or relaxing breathing exercises before bed.",
            contentBn = "মোবাইল স্ক্রিনের নীল আলো মেলাটোনিন হরমোন নিঃসরণে বাধা দেয়। ঘুমাতে যাওয়ার আগেই ফোন দূরে রেখে হালকা বই পড়ার চেষ্টা করুন।",
            iconName = "smartphone"
        ),
        HealthTip(
            id = "sl_3",
            category = TipCategory.SLEEP,
            titleEn = "Manage Daily Stress Naturally",
            titleBn = "মানসিক চাপ ও দুশ্চিন্তা নিয়ন্ত্রণে রাখুন",
            contentEn = "Chronic stress releases cortisol, which encourages abdominal fat accumulation. Simple deep breathing (pranayama), prayer, or nature walks bring calm.",
            contentBn = "অতিরিক্ত মানসিক চাপে পেটের চারপাশে চর্বি জমার সম্ভাবনা বাড়ে। প্রতিদিন ১০ মিনিট গভীর শ্বাস-প্রশ্বাসের অনুশীলন বা মেডিটেশন মানসিক প্রশান্তি দেয়।",
            iconName = "spa"
        ),
        HealthTip(
            id = "sl_4",
            category = TipCategory.SLEEP,
            titleEn = "Maintain Consistent Sleep Schedules",
            titleBn = "ঘুমানোর নির্দিষ্ট সময় বজায় রাখুন",
            contentEn = "Going to bed and waking up at the same hour every day, even on weekends, aligns your circadian rhythm and optimizes your metabolic rate.",
            contentBn = "ছুটির দিনেও চেষ্টা করুন প্রতিদিন একই সময়ে ঘুমাতে যাওয়া এবং ঘুম থেকে ওঠার। এটি শরীরের অভ্যন্তরীণ ঘড়ি (সার্কাডিয়ান রিদম) ঠিক রাখে।",
            iconName = "alarm"
        ),
        HealthTip(
            id = "sl_5",
            category = TipCategory.SLEEP,
            titleEn = "Avoid Heavy Meals Late at Night",
            titleBn = "ঘুমানোর ঠিক আগে ভারী খাবার নয়",
            contentEn = "Eat your dinner at least 2 hours before lying down. Late digestion can interfere with deep sleep stages and exacerbate acid reflux.",
            contentBn = "ঘুমানোর অন্তত ২ ঘণ্টা আগে রাতের খাবার শেষ করুন। রাতে হালকা খাবার খেলে ঘুমের মান ভালো হয় এবং অ্যাসিডিটির সমস্যা কমে।",
            iconName = "nights_stay"
        ),

        // Hydration (5 tips)
        HealthTip(
            id = "hy_1",
            category = TipCategory.HYDRATION,
            titleEn = "Drink 2 to 3 Liters of Water Daily",
            titleBn = "প্রতিদিন ২ থেকে ৩ লিটার বিশুদ্ধ পানি",
            contentEn = "Adequate water helps filter waste through kidneys, supports metabolic chemical reactions, and prevents fatigue and headaches.",
            contentBn = "একজন সুস্থ প্রাপ্তবয়স্ক মানুষের জন্য দৈনিক ৮-১০ গ্লাস (২-৩ লিটার) পানি পান করা অত্যন্ত জরুরি। এটি শরীর থেকে বর্জ্য দূর করতে সাহায্য করে।",
            iconName = "water_drop"
        ),
        HealthTip(
            id = "hy_2",
            category = TipCategory.HYDRATION,
            titleEn = "Start Your Morning with Water",
            titleBn = "সকাল শুরু করুন এক গ্লাস সাধারণ পানি দিয়ে",
            contentEn = "Drink a glass of warm or room-temperature water right after waking up to rehydrate your body after 7-8 hours of sleep and stimulate digestion.",
            contentBn = "ঘুম থেকে উঠে এক গ্লাস স্বাভাবিক তাপমাত্রার পানি পান করলে মেটাবলিজম সক্রিয় হয় এবং পরিপাকতন্ত্র সতেজ হয়ে ওঠে।",
            iconName = "wb_sunny"
        ),
        HealthTip(
            id = "hy_3",
            category = TipCategory.HYDRATION,
            titleEn = "Don't Confuse Thirst with Hunger",
            titleBn = "তৃষ্ণাকে ক্ষুধা ভেবে ভুল করবেন না",
            contentEn = "The brain signals for thirst and mild hunger can feel surprisingly similar. When sudden cravings occur, drink a glass of water first and wait 10 minutes.",
            contentBn = "অনেক সময় শরীরের পানির পিপাসাকে আমরা ক্ষুধা বলে ভুল করি। অসময়ে ক্ষুধা পেলে আগে এক গ্লাস পানি পান করে কিছুক্ষণ অপেক্ষা করুন।",
            iconName = "local_drink"
        ),
        HealthTip(
            id = "hy_4",
            category = TipCategory.HYDRATION,
            titleEn = "Drink More When Exercising or in Heat",
            titleBn = "গরম ও শরীরচর্চার সময়ে বেশি পানি পান করুন",
            contentEn = "In hot weather or during rigorous workouts, fluid loss via perspiration increases. Drink water before, during, and after physical exertion.",
            contentBn = "রোদে বের হলে বা ঘাম হলে শরীরে পানির ঘাটতি দেখা দিতে পারে। ব্যায়ামের সময় অল্প অল্প করে চুমুক দিয়ে পানি পান করুন।",
            iconName = "thermostat"
        ),
        HealthTip(
            id = "hy_5",
            category = TipCategory.HYDRATION,
            titleEn = "Check Your Urine Color",
            titleBn = "প্রস্রাবের রঙ দেখে পানির পর্যাপ্ততা বুঝুন",
            contentEn = "Pale, straw-colored or clear urine signifies good hydration. If it looks dark yellow or amber, it is a clear indicator that you need to drink more fluids immediately.",
            contentBn = "প্রস্রাবের রঙ হালকা খড় বা স্বচ্ছ হলে বুঝতে হবে শরীর সঠিকভাবে হাইড্রেটেড। গাড় হলুদ রঙ হলে সাথে সাথে পানি পানের পরিমাণ বাড়িয়ে দিন।",
            iconName = "opacity"
        )
    )

    fun getTipsForCategory(category: TipCategory): List<HealthTip> {
        return tips.filter { it.category == category }
    }
}
