package com.example.domain.calculator

import kotlin.math.round

object BmiCalculator {

    /**
     * Calculates BMI = weight (kg) / (height (m) * height (m))
     * Returns rounded to 1 decimal place.
     */
    fun calculateBmi(weightKg: Double, heightCm: Double): Double {
        if (weightKg <= 0.0 || heightCm <= 0.0) return 0.0
        val heightM = heightCm / 100.0
        val bmi = weightKg / (heightM * heightM)
        return round(bmi * 10.0) / 10.0
    }

    /**
     * Determines the adult BMI Category
     */
    fun getCategory(bmi: Double): BmiCategory {
        return BmiCategory.fromBmi(bmi)
    }

    /**
     * Returns estimated healthy weight range (kg) based on 18.5 - 24.9 BMI
     */
    fun calculateHealthyWeightRange(heightCm: Double): Pair<Double, Double> {
        if (heightCm <= 0.0) return Pair(0.0, 0.0)
        val heightM = heightCm / 100.0
        val minKg = round((18.5 * heightM * heightM) * 10.0) / 10.0
        val maxKg = round((24.9 * heightM * heightM) * 10.0) / 10.0
        return Pair(minKg, maxKg)
    }

    fun lbToKg(lb: Double): Double {
        val kg = lb * 0.45359237
        return round(kg * 10.0) / 10.0
    }

    fun kgToLb(kg: Double): Double {
        val lb = kg / 0.45359237
        return round(lb * 10.0) / 10.0
    }

    fun feetInchesToCm(feet: Int, inches: Double): Double {
        val totalInches = (feet * 12) + inches
        val cm = totalInches * 2.54
        return round(cm * 10.0) / 10.0
    }

    fun cmToFeetInches(cm: Double): Pair<Int, Double> {
        val totalInches = cm / 2.54
        val feet = (totalInches / 12).toInt()
        val inches = round((totalInches % 12) * 10.0) / 10.0
        return Pair(feet, inches)
    }

    /**
     * Bengali digit converter (e.g. 24.2 -> ২৪.২)
     */
    fun toBengaliDigits(input: String): String {
        val englishToBengaliMap = mapOf(
            '0' to '০', '1' to '১', '2' to '২', '3' to '৩', '4' to '৪',
            '5' to '৫', '6' to '৬', '7' to '৭', '8' to '৮', '9' to '৯',
            '.' to '.'
        )
        return input.map { englishToBengaliMap[it] ?: it }.joinToString("")
    }

    fun formatNumber(value: Double, isBengali: Boolean): String {
        val str = if (value % 1.0 == 0.0) {
            value.toInt().toString()
        } else {
            String.format(java.util.Locale.US, "%.1f", value)
        }
        return if (isBengali) toBengaliDigits(str) else str
    }
}
