package com.example.domain.calculator

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.BmiNormalColor
import com.example.ui.theme.BmiObeseColor
import com.example.ui.theme.BmiOverweightColor
import com.example.ui.theme.BmiUnderweightColor

enum class BmiCategory(
    val key: String,
    val nameEn: String,
    val nameBn: String,
    val color: Color,
    val adviceEn: String,
    val adviceBn: String
) {
    UNDERWEIGHT(
        key = "underweight",
        nameEn = "Underweight",
        nameBn = "স্বাভাবিকের চেয়ে কম",
        color = BmiUnderweightColor,
        adviceEn = "Your BMI indicates you are below the recommended healthy weight range. Consider nutrient-rich wholesome meals, adequate calories, and consult a nutritionist or doctor if necessary.",
        adviceBn = "আপনার ওজন স্বাভাবিকের চেয়ে কম। পর্যাপ্ত পুষ্টিকর সুষম খাবার গ্রহণ করুন এবং প্রয়োজনে একজন পুষ্টিবিদ বা ডাক্তারের পরামর্শ নিন।"
    ),
    NORMAL(
        key = "normal",
        nameEn = "Normal Weight",
        nameBn = "স্বাভাবিক ওজন (আদর্শ)",
        color = BmiNormalColor,
        adviceEn = "Congratulations! Your BMI is within the healthy weight range. Maintain this with regular physical activity and a balanced diet.",
        adviceBn = "অভিনন্দন! আপনার ওজন চমৎকার ও স্বাস্থ্যকর সীমার মধ্যে রয়েছে। নিয়মিত ব্যায়াম ও পুষ্টিকর সুষম খাদ্যাভ্যাস বজায় রাখুন।"
    ),
    OVERWEIGHT(
        key = "overweight",
        nameEn = "Overweight",
        nameBn = "অতিরিক্ত ওজন",
        color = BmiOverweightColor,
        adviceEn = "Your BMI is above the ideal range. Adopting portion control, reducing sugary and deep-fried foods, and walking 30 minutes daily can help you reach a healthy weight.",
        adviceBn = "আপনার ওজন স্বাভাবিকের চেয়ে কিছুটা বেশি। মিষ্টি ও অতিরিক্ত তৈলাক্ত খাবার পরিহার এবং প্রতিদিন ৩০ মিনিট নিয়মিত হাঁটার অভ্যাস গড়ে তুলুন।"
    ),
    OBESE(
        key = "obese",
        nameEn = "Obese",
        nameBn = "স্থূলতা (অতিরিক্ত মেদ)",
        color = BmiObeseColor,
        adviceEn = "Your BMI is in the obesity category, which may carry cardiovascular or metabolic risks. We strongly recommend consulting a physician or registered dietitian for a healthy lifestyle plan.",
        adviceBn = "আপনার ওজন স্থূলতার পর্যায়ে রয়েছে, যা স্বাস্থ্যের জন্য ঝুঁকির কারণ হতে পারে। একজন রেজিস্টার্ড পুষ্টিবিদ বা চিকিৎসকের পরামর্শ নিয়ে স্বাস্থ্যকর ডায়েট চার্ট অনুসরণ করুন।"
    );

    companion object {
        fun fromKey(key: String): BmiCategory =
            entries.find { it.key.equals(key, ignoreCase = true) } ?: NORMAL

        fun fromBmi(bmi: Double): BmiCategory = when {
            bmi < 18.5 -> UNDERWEIGHT
            bmi < 25.0 -> NORMAL
            bmi < 30.0 -> OVERWEIGHT
            else -> OBESE
        }
    }
}
