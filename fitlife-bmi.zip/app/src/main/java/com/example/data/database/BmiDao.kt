package com.example.data.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface BmiDao {
    @Query("SELECT * FROM bmi_records ORDER BY timestamp DESC")
    fun getAllRecordsDesc(): Flow<List<BmiRecord>>

    @Query("SELECT * FROM bmi_records ORDER BY timestamp ASC")
    fun getAllRecordsAsc(): Flow<List<BmiRecord>>

    @Query("SELECT * FROM bmi_records WHERE timestamp >= :sinceTimestamp ORDER BY timestamp ASC")
    fun getRecordsSince(sinceTimestamp: Long): Flow<List<BmiRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecord(record: BmiRecord): Long

    @Query("DELETE FROM bmi_records WHERE id = :id")
    suspend fun deleteRecord(id: Long)

    @Query("DELETE FROM bmi_records")
    suspend fun clearAll()

    @Query("SELECT COUNT(*) FROM bmi_records")
    fun getCount(): Flow<Int>
}
