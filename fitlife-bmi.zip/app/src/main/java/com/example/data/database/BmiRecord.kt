package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "bmi_records")
data class BmiRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val age: Int,
    val gender: String, // "male", "female"
    val weightKg: Double,
    val heightCm: Double,
    val bmiValue: Double,
    val categoryKey: String // "underweight", "normal", "overweight", "obese"
)
