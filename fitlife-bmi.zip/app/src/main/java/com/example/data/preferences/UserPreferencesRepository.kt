package com.example.data.preferences

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "user_preferences")

enum class AppLanguage(val code: String, val displayName: String, val nativeName: String) {
    BENGALI("bn", "Bengali", "বাংলা"),
    ENGLISH("en", "English", "English");

    companion object {
        fun fromCode(code: String): AppLanguage =
            entries.find { it.code.equals(code, ignoreCase = true) } ?: BENGALI
    }
}

enum class ThemeMode(val title: String) {
    SYSTEM("System Default"),
    LIGHT("Light Mode"),
    DARK("Dark Mode");

    companion object {
        fun fromString(value: String): ThemeMode =
            try { valueOf(value) } catch (e: Exception) { SYSTEM }
    }
}

enum class WeightUnit(val label: String, val bnLabel: String) {
    KG("kg", "কেজি"),
    LB("lb", "পাউন্ড");

    companion object {
        fun fromString(value: String): WeightUnit =
            try { valueOf(value) } catch (e: Exception) { KG }
    }
}

enum class HeightUnit(val label: String, val bnLabel: String) {
    CM("cm", "সেমি"),
    FT_IN("ft/in", "ফুট/ইঞ্চি");

    companion object {
        fun fromString(value: String): HeightUnit =
            try { valueOf(value) } catch (e: Exception) { CM }
    }
}

data class UserPreferences(
    val language: AppLanguage = AppLanguage.BENGALI,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val weightUnit: WeightUnit = WeightUnit.KG,
    val heightUnit: HeightUnit = HeightUnit.CM
)

class UserPreferencesRepository(private val context: Context) {

    private object PreferencesKeys {
        val LANGUAGE = stringPreferencesKey("language")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val WEIGHT_UNIT = stringPreferencesKey("weight_unit")
        val HEIGHT_UNIT = stringPreferencesKey("height_unit")
    }

    val userPreferencesFlow: Flow<UserPreferences> = context.dataStore.data.map { preferences ->
        val langCode = preferences[PreferencesKeys.LANGUAGE] ?: AppLanguage.BENGALI.code
        val themeStr = preferences[PreferencesKeys.THEME_MODE] ?: ThemeMode.SYSTEM.name
        val weightStr = preferences[PreferencesKeys.WEIGHT_UNIT] ?: WeightUnit.KG.name
        val heightStr = preferences[PreferencesKeys.HEIGHT_UNIT] ?: HeightUnit.CM.name

        UserPreferences(
            language = AppLanguage.fromCode(langCode),
            themeMode = ThemeMode.fromString(themeStr),
            weightUnit = WeightUnit.fromString(weightStr),
            heightUnit = HeightUnit.fromString(heightStr)
        )
    }

    suspend fun setLanguage(language: AppLanguage) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.LANGUAGE] = language.code
        }
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.THEME_MODE] = mode.name
        }
    }

    suspend fun setWeightUnit(unit: WeightUnit) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.WEIGHT_UNIT] = unit.name
        }
    }

    suspend fun setHeightUnit(unit: HeightUnit) {
        context.dataStore.edit { preferences ->
            preferences[PreferencesKeys.HEIGHT_UNIT] = unit.name
        }
    }
}
