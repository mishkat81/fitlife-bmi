package com.example.data.repository

import com.example.data.database.BmiDao
import com.example.data.database.BmiRecord
import kotlinx.coroutines.flow.Flow

class BmiRepository(private val bmiDao: BmiDao) {

    fun getAllRecords(descending: Boolean = true): Flow<List<BmiRecord>> {
        return if (descending) bmiDao.getAllRecordsDesc() else bmiDao.getAllRecordsAsc()
    }

    fun getRecordsSince(sinceTimestamp: Long): Flow<List<BmiRecord>> {
        return bmiDao.getRecordsSince(sinceTimestamp)
    }

    suspend fun insertRecord(record: BmiRecord): Long {
        return bmiDao.insertRecord(record)
    }

    suspend fun deleteRecord(id: Long) {
        bmiDao.deleteRecord(id)
    }

    suspend fun clearAll() {
        bmiDao.clearAll()
    }

    fun getRecordCount(): Flow<Int> {
        return bmiDao.getCount()
    }
}
