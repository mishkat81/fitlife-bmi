package com.example

import com.example.domain.calculator.BmiCalculator
import com.example.domain.calculator.BmiCategory
import org.junit.Assert.assertEquals
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testBmiCalculations() {
        // Test examples requested by the user:
        // 70 kg / 170 cm = BMI 24.2
        val bmi1 = BmiCalculator.calculateBmi(70.0, 170.0)
        assertEquals(24.2, bmi1, 0.05)
        assertEquals(BmiCategory.NORMAL, BmiCalculator.getCategory(bmi1))

        // 50 kg / 170 cm = BMI 17.3
        val bmi2 = BmiCalculator.calculateBmi(50.0, 170.0)
        assertEquals(17.3, bmi2, 0.05)
        assertEquals(BmiCategory.UNDERWEIGHT, BmiCalculator.getCategory(bmi2))

        // 85 kg / 170 cm = BMI 29.4
        val bmi3 = BmiCalculator.calculateBmi(85.0, 170.0)
        assertEquals(29.4, bmi3, 0.05)
        assertEquals(BmiCategory.OVERWEIGHT, BmiCalculator.getCategory(bmi3))

        // 100 kg / 170 cm = BMI 34.6
        val bmi4 = BmiCalculator.calculateBmi(100.0, 170.0)
        assertEquals(34.6, bmi4, 0.05)
        assertEquals(BmiCategory.OBESE, BmiCalculator.getCategory(bmi4))
    }

    @Test
    fun testConversions() {
        val kg = 70.0
        val lb = BmiCalculator.kgToLb(kg)
        val convertedBackKg = BmiCalculator.lbToKg(lb)
        assertEquals(kg, convertedBackKg, 0.2)

        val cm = BmiCalculator.feetInchesToCm(5, 7.0)
        assertEquals(170.2, cm, 0.2)
    }

    @Test
    fun testBengaliDigits() {
        val bengali = BmiCalculator.toBengaliDigits("24.2")
        assertEquals("২৪.২", bengali)

        val devPhone = BmiCalculator.toBengaliDigits("01912425836")
        assertEquals("০১৯১২৪২৫৮৩৬", devPhone)
    }
}
